@echo off
setlocal enabledelayedexpansion
echo ============================================
echo DevSecOps Platform - Setup
echo ============================================

cd /d "%~dp0\.."

if not exist ".env" (
    echo Creating .env from .env.example ...
    copy ".env.example" ".env" >nul
    echo IMPORTANT: edit .env and set JWT_SECRET_KEY / INGEST_API_KEY before starting.
)

echo.
echo [1/4] Checking Docker...
docker --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Docker Desktop is required. Install it and re-run setup.bat.
    exit /b 1
)

echo [2/4] Starting PostgreSQL container...
docker compose -f infra\docker\docker-compose.yml up -d db
if errorlevel 1 (
    echo ERROR: Failed to start database container.
    exit /b 1
)

echo [3/4] Creating backend virtual environment ...
cd backend
if not exist "venv" (
    python -m venv venv
)
call venv\Scripts\activate.bat
pip install --upgrade pip >nul
pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: pip install failed.
    exit /b 1
)

echo [4/4] Running migrations and seeding demo data ...
set /p WAIT=Waiting 5s for Postgres to accept connections...
timeout /t 5 /nobreak >nul
alembic upgrade head
python -m app.db.seed

cd ..
echo.
echo Installing frontend dependencies ...
cd frontend
call npm install
cd ..

echo.
echo ============================================
echo Setup complete. Run scripts\start.bat next.
echo Demo login: admin@example.com / ChangeMe123!
echo ============================================
endlocal
