@echo off
cd /d "%~dp0\.."

echo Stopping backend/frontend dev windows (uvicorn / next dev) ...
taskkill /FI "WINDOWTITLE eq DevSecOps Backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq DevSecOps Frontend*" /T /F >nul 2>&1

echo Stopping database container ...
docker compose -f infra\docker\docker-compose.yml stop db

echo All services stopped.
