@echo off
cd /d "%~dp0\.."

echo Starting database...
docker compose -f infra\docker\docker-compose.yml up -d db

echo Starting backend (FastAPI) on http://localhost:8000 ...
start "DevSecOps Backend" cmd /k "cd backend && call venv\Scripts\activate.bat && uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload"

echo Starting frontend (Next.js) on http://localhost:3000 ...
start "DevSecOps Frontend" cmd /k "cd frontend && npm run dev"

echo.
echo All services starting in separate windows. Close those windows or run stop.bat to stop.
