"""
Release Gate Engine.

Pure function(s): given a list of findings (as dicts with 'type', 'severity',
'license_id', 'status') and a Policy, decide GateStatus + a human-readable reason.
Kept side-effect-free and unit-testable in isolation from the DB/HTTP layers.
"""
from collections import Counter
from dataclasses import dataclass


@dataclass
class GateDecision:
    status: str  # "passed" | "failed"
    reason: str
    counts: dict[str, int]


def evaluate_gate(findings: list[dict], policy) -> GateDecision:
    """
    findings: list of dicts with keys: type, severity, license_id (optional), status
    policy: an object/row with max_critical, max_high, max_medium, block_on_secrets,
            denied_licenses, allowed_licenses
    Only 'open' status findings count toward the gate — triaged (ignored /
    false_positive / accepted_risk) findings are excluded, and each such
    exclusion is expected to have already been audit-logged by the triage endpoint.
    """
    active = [f for f in findings if f.get("status", "open") == "open"]

    sev_counts = Counter(f["severity"] for f in active)
    counts = {
        "critical": sev_counts.get("critical", 0),
        "high": sev_counts.get("high", 0),
        "medium": sev_counts.get("medium", 0),
        "low": sev_counts.get("low", 0),
        "info": sev_counts.get("info", 0),
    }

    reasons = []

    if counts["critical"] > policy.max_critical:
        reasons.append(f"{counts['critical']} critical finding(s) exceed max_critical={policy.max_critical}")

    if counts["high"] > policy.max_high:
        reasons.append(f"{counts['high']} high finding(s) exceed max_high={policy.max_high}")

    if counts["medium"] > policy.max_medium:
        reasons.append(f"{counts['medium']} medium finding(s) exceed max_medium={policy.max_medium}")

    secret_findings = [f for f in active if f["type"] == "secret"]
    if policy.block_on_secrets and secret_findings:
        reasons.append(f"{len(secret_findings)} unresolved secret finding(s) detected")

    denied = set(policy.denied_licenses or [])
    allowed = set(policy.allowed_licenses or [])
    for f in active:
        if f["type"] != "license":
            continue
        lic = f.get("license_id")
        if not lic:
            continue
        if lic in denied:
            reasons.append(f"denied license '{lic}' used by {f.get('package_name')}")
        elif allowed and lic not in allowed:
            reasons.append(f"license '{lic}' ({f.get('package_name')}) is not on the allow-list")

    if reasons:
        return GateDecision(status="failed", reason="; ".join(reasons), counts=counts)
    return GateDecision(status="passed", reason="All policy thresholds satisfied", counts=counts)
