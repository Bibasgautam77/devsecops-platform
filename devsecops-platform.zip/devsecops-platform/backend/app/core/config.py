"""
Central application configuration.

All values are read from environment variables (see .env.example at repo root).
Nothing here is hard-coded to a real secret; defaults are safe-for-local-dev only
and are intentionally obvious placeholders so they are never mistaken for
production values.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Core ---
    ENVIRONMENT: str = "development"
    APP_NAME: str = "DevSecOps Supply-Chain Platform"
    API_V1_PREFIX: str = "/api/v1"
    LOG_LEVEL: str = "INFO"

    # --- Database ---
    DATABASE_URL: str = "postgresql+psycopg://devsecops:devsecops@localhost:5432/devsecops"

    # --- Auth ---
    JWT_SECRET_KEY: str = "CHANGE_ME_INSECURE_DEV_ONLY_SECRET"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # --- CORS ---
    CORS_ORIGINS: List[str] = ["http://localhost:3000"]

    # --- Ingestion (used by GitHub Actions to push scan results) ---
    INGEST_API_KEY: str = "CHANGE_ME_INGEST_KEY"

    # --- Optional live GitHub App integration (PR comments / Check Runs) ---
    GITHUB_APP_ID: str | None = None
    GITHUB_APP_PRIVATE_KEY: str | None = None  # PEM contents, injected via env/secret store
    GITHUB_WEBHOOK_SECRET: str | None = None

    # --- Policy defaults (overridable per-project via API) ---
    DEFAULT_MAX_CRITICAL: int = 0
    DEFAULT_MAX_HIGH: int = 5
    DEFAULT_BLOCK_ON_SECRETS: bool = True
    DEFAULT_DENIED_LICENSES: List[str] = ["GPL-3.0", "AGPL-3.0"]

    @property
    def github_app_configured(self) -> bool:
        return bool(self.GITHUB_APP_ID and self.GITHUB_APP_PRIVATE_KEY)


@lru_cache
def get_settings() -> Settings:
    return Settings()
