"""
Seeds clearly-marked SYNTHETIC demo data so the dashboard is populated on
first run without needing a live GitHub connection. Every seeded Project has
is_demo=True and every seeded repo name is prefixed 'demo/'. Run with:

    python -m app.db.seed
"""
from app.core.security import hash_password
from app.db.session import Base, SessionLocal, engine
from app.models.models import (
    Finding,
    FindingStatus,
    FindingType,
    GateStatus,
    Policy,
    Project,
    Role,
    Scan,
    Severity,
    User,
)


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            admin = User(
                email="admin@example.com",
                hashed_password=hash_password("ChangeMe123!"),
                full_name="Demo Admin",
                role=Role.admin,
            )
            db.add(admin)

        if db.query(Project).filter_by(repo_full_name="demo/sample-service").first():
            print("Demo data already seeded.")
            return

        project = Project(
            name="sample-service",
            repo_full_name="demo/sample-service",
            default_branch="main",
            is_demo=True,
        )
        db.add(project)
        db.flush()

        db.add(
            Policy(
                project_id=project.id,
                max_critical=0,
                max_high=5,
                block_on_secrets=True,
                denied_licenses=["GPL-3.0", "AGPL-3.0"],
            )
        )

        scan = Scan(
            project_id=project.id,
            commit_sha="a1b2c3d4synthetic",
            branch="main",
            gate_status=GateStatus.failed,
            gate_reason="1 critical finding(s) exceed max_critical=0; 1 unresolved secret finding(s) detected",
        )
        db.add(scan)
        db.flush()

        demo_findings = [
            Finding(
                scan_id=scan.id,
                type=FindingType.sast,
                severity=Severity.critical,
                tool="semgrep",
                rule_id="python.lang.security.audit.exec-detected",
                title="Use of exec() with dynamic input (SYNTHETIC DEMO FINDING)",
                file_path="demo/app/utils.py",
                line_start=42,
                line_end=42,
                status=FindingStatus.open,
            ),
            Finding(
                scan_id=scan.id,
                type=FindingType.sca,
                severity=Severity.high,
                tool="trivy",
                rule_id="CVE-2024-DEMO-0001",
                title="requests 2.25.0 — CVE-2024-DEMO-0001 (SYNTHETIC DEMO FINDING)",
                package_name="requests",
                package_version="2.25.0",
                cve_id="CVE-2024-DEMO-0001",
                status=FindingStatus.open,
            ),
            Finding(
                scan_id=scan.id,
                type=FindingType.secret,
                severity=Severity.critical,
                tool="gitleaks",
                rule_id="generic-api-key",
                title="Secret detected: generic-api-key (SYNTHETIC DEMO FINDING)",
                file_path="demo/config/settings.py",
                line_start=10,
                redacted_secret_preview="sk***23",
                status=FindingStatus.open,
            ),
        ]
        db.add_all(demo_findings)
        db.commit()
        print("Seeded synthetic demo project 'demo/sample-service'.")
    finally:
        db.close()


if __name__ == "__main__":
    run()
