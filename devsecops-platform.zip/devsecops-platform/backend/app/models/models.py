"""
Core ORM models.

Entities:
  User        - platform account (RBAC: admin / maintainer / viewer)
  Project     - a connected repository
  Scan        - one CI run's collection of scanner outputs for a commit/PR
  Finding     - one normalized finding (SAST/SCA/secret/container/IaC)
  Sbom        - stored CycloneDX SBOM document for a scan
  Policy      - per-project gate configuration
  AuditLog    - immutable record of triage/policy/admin actions
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


def gen_uuid() -> str:
    return str(uuid.uuid4())


class Role(str, enum.Enum):
    admin = "admin"
    maintainer = "maintainer"
    viewer = "viewer"


class Severity(str, enum.Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    info = "info"


class FindingType(str, enum.Enum):
    sast = "sast"
    sca = "sca"
    secret = "secret"
    container = "container"
    iac = "iac"
    license = "license"


class FindingStatus(str, enum.Enum):
    open = "open"
    ignored = "ignored"
    false_positive = "false_positive"
    accepted_risk = "accepted_risk"
    resolved = "resolved"


class GateStatus(str, enum.Enum):
    pending = "pending"
    passed = "passed"
    failed = "failed"


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    email: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String, nullable=False)
    full_name: Mapped[str] = mapped_column(String, nullable=True)
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.viewer, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    name: Mapped[str] = mapped_column(String, nullable=False)
    repo_full_name: Mapped[str] = mapped_column(String, unique=True, nullable=False)  # e.g. "org/repo"
    default_branch: Mapped[str] = mapped_column(String, default="main")
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    scans: Mapped[list["Scan"]] = relationship(back_populates="project", cascade="all, delete-orphan")
    policy: Mapped["Policy"] = relationship(back_populates="project", uselist=False, cascade="all, delete-orphan")


class Scan(Base):
    __tablename__ = "scans"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False)
    commit_sha: Mapped[str] = mapped_column(String, nullable=False)
    branch: Mapped[str] = mapped_column(String, nullable=False)
    pr_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    triggered_by: Mapped[str] = mapped_column(String, default="github-actions")
    gate_status: Mapped[GateStatus] = mapped_column(Enum(GateStatus), default=GateStatus.pending)
    gate_reason: Mapped[str] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    project: Mapped["Project"] = relationship(back_populates="scans")
    findings: Mapped[list["Finding"]] = relationship(back_populates="scan", cascade="all, delete-orphan")
    sboms: Mapped[list["Sbom"]] = relationship(back_populates="scan", cascade="all, delete-orphan")


class Finding(Base):
    __tablename__ = "findings"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id"), nullable=False)
    type: Mapped[FindingType] = mapped_column(Enum(FindingType), nullable=False)
    severity: Mapped[Severity] = mapped_column(Enum(Severity), nullable=False)
    tool: Mapped[str] = mapped_column(String, nullable=False)  # semgrep|trivy|gitleaks|syft
    rule_id: Mapped[str] = mapped_column(String, nullable=True)
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    file_path: Mapped[str] = mapped_column(String, nullable=True)
    line_start: Mapped[int | None] = mapped_column(Integer, nullable=True)
    line_end: Mapped[int | None] = mapped_column(Integer, nullable=True)
    package_name: Mapped[str] = mapped_column(String, nullable=True)
    package_version: Mapped[str] = mapped_column(String, nullable=True)
    cve_id: Mapped[str] = mapped_column(String, nullable=True)
    license_id: Mapped[str] = mapped_column(String, nullable=True)
    # Secrets are never stored raw: only a redacted preview + sha256 fingerprint.
    redacted_secret_preview: Mapped[str] = mapped_column(String, nullable=True)
    secret_fingerprint: Mapped[str] = mapped_column(String, nullable=True)
    status: Mapped[FindingStatus] = mapped_column(Enum(FindingStatus), default=FindingStatus.open)
    raw: Mapped[dict] = mapped_column(JSON, nullable=True)  # original normalized tool payload fragment
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    scan: Mapped["Scan"] = relationship(back_populates="findings")


class Sbom(Base):
    __tablename__ = "sboms"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id"), nullable=False)
    format: Mapped[str] = mapped_column(String, default="CycloneDX")
    component_count: Mapped[int] = mapped_column(Integer, default=0)
    document: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    scan: Mapped["Scan"] = relationship(back_populates="sboms")


class Policy(Base):
    __tablename__ = "policies"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), unique=True, nullable=False)
    max_critical: Mapped[int] = mapped_column(Integer, default=0)
    max_high: Mapped[int] = mapped_column(Integer, default=5)
    max_medium: Mapped[int] = mapped_column(Integer, default=50)
    block_on_secrets: Mapped[bool] = mapped_column(Boolean, default=True)
    denied_licenses: Mapped[list] = mapped_column(JSON, default=list)
    allowed_licenses: Mapped[list] = mapped_column(JSON, default=list)  # empty = allow-all except denied
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    project: Mapped["Project"] = relationship(back_populates="policy")


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_uuid)
    actor_user_id: Mapped[str] = mapped_column(String, nullable=True)
    actor_label: Mapped[str] = mapped_column(String, nullable=False)  # e.g. "user:jane" or "system:ci"
    action: Mapped[str] = mapped_column(String, nullable=False)  # e.g. "finding.triage", "policy.update"
    entity_type: Mapped[str] = mapped_column(String, nullable=False)
    entity_id: Mapped[str] = mapped_column(String, nullable=False)
    details: Mapped[dict] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
