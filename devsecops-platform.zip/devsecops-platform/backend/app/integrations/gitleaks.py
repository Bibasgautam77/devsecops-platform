"""
Normalizer for `gitleaks detect --report-format json` output.

CRITICAL SAFETY RULE: raw secret material must never be persisted or displayed.
We store only a SHA-256 fingerprint (for de-duplication) and a redacted preview.
"""
import hashlib
from typing import Any


def _fingerprint(secret: str) -> str:
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()


def _redact(secret: str) -> str:
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return secret[:2] + "*" * (len(secret) - 4) + secret[-2:]


def normalize_gitleaks(report: list[dict[str, Any]]) -> list[dict]:
    findings = []
    for leak in report or []:
        secret = leak.get("Secret", "")
        findings.append(
            {
                "type": "secret",
                "severity": "critical",
                "tool": "gitleaks",
                "rule_id": leak.get("RuleID"),
                "title": f"Secret detected: {leak.get('RuleID', 'unknown rule')}",
                "description": leak.get("Description"),
                "file_path": leak.get("File"),
                "line_start": leak.get("StartLine"),
                "line_end": leak.get("EndLine"),
                "redacted_secret_preview": _redact(secret),
                "secret_fingerprint": _fingerprint(secret) if secret else None,
                "raw": {k: v for k, v in leak.items() if k != "Secret"},
            }
        )
    return findings
