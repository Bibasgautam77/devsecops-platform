"""
Normalizer for `semgrep --json` output into our internal Finding shape.

Expected input: the parsed JSON produced by:
    semgrep scan --config auto --json --output semgrep.json

We only read fields; we never execute or re-run semgrep from the backend —
scanning always happens in the CI runner (see .github/workflows/security-ci.yml),
never triggered by this API against arbitrary user-supplied targets.
"""
from typing import Any

_SEVERITY_MAP = {
    "ERROR": "critical",
    "WARNING": "high",
    "INFO": "medium",
}


def normalize_semgrep(report: dict[str, Any]) -> list[dict]:
    findings = []
    for result in report.get("results", []):
        extra = result.get("extra", {})
        sev = _SEVERITY_MAP.get(extra.get("severity", "INFO"), "medium")
        findings.append(
            {
                "type": "sast",
                "severity": sev,
                "tool": "semgrep",
                "rule_id": result.get("check_id"),
                "title": extra.get("message", result.get("check_id", "Semgrep finding"))[:250],
                "description": extra.get("message"),
                "file_path": result.get("path"),
                "line_start": result.get("start", {}).get("line"),
                "line_end": result.get("end", {}).get("line"),
                "raw": result,
            }
        )
    return findings
