"""
Normalizer for Trivy JSON output.

Trivy is used in three modes in the CI workflow, all producing the same
top-level `Results[]` schema:
    trivy fs   .                 -> dependency (SCA) vulnerabilities
    trivy image <built-image>    -> container vulnerabilities
    trivy config .               -> IaC misconfigurations (Dockerfile/K8s/Terraform)

`scan_mode` tells us which FindingType to tag results with.
"""
from typing import Any

_SEVERITY_MAP = {
    "CRITICAL": "critical",
    "HIGH": "high",
    "MEDIUM": "medium",
    "LOW": "low",
    "UNKNOWN": "info",
}


def normalize_trivy(report: dict[str, Any], scan_mode: str) -> list[dict]:
    """scan_mode in {'sca', 'container', 'iac'}"""
    findings = []
    for result in report.get("Results", []) or []:
        target = result.get("Target")

        for vuln in result.get("Vulnerabilities", []) or []:
            sev = _SEVERITY_MAP.get(vuln.get("Severity", "UNKNOWN"), "info")
            findings.append(
                {
                    "type": scan_mode if scan_mode in ("sca", "container") else "sca",
                    "severity": sev,
                    "tool": "trivy",
                    "rule_id": vuln.get("VulnerabilityID"),
                    "title": f"{vuln.get('PkgName')} {vuln.get('InstalledVersion')} — {vuln.get('VulnerabilityID')}",
                    "description": vuln.get("Description"),
                    "file_path": target,
                    "package_name": vuln.get("PkgName"),
                    "package_version": vuln.get("InstalledVersion"),
                    "cve_id": vuln.get("VulnerabilityID"),
                    "raw": vuln,
                }
            )

        for mis in result.get("Misconfigurations", []) or []:
            sev = _SEVERITY_MAP.get(mis.get("Severity", "UNKNOWN"), "info")
            findings.append(
                {
                    "type": "iac",
                    "severity": sev,
                    "tool": "trivy",
                    "rule_id": mis.get("ID"),
                    "title": mis.get("Title", "IaC misconfiguration")[:250],
                    "description": mis.get("Description"),
                    "file_path": target,
                    "raw": mis,
                }
            )

        for secret in result.get("Secrets", []) or []:
            sev = _SEVERITY_MAP.get(secret.get("Severity", "HIGH"), "high")
            findings.append(
                {
                    "type": "secret",
                    "severity": sev,
                    "tool": "trivy",
                    "rule_id": secret.get("RuleID"),
                    "title": f"Potential secret: {secret.get('Category', 'unknown')}",
                    "file_path": target,
                    "line_start": secret.get("StartLine"),
                    "line_end": secret.get("EndLine"),
                    # never store the raw match; redact it
                    "redacted_secret_preview": _redact(secret.get("Match", "")),
                    "raw": {k: v for k, v in secret.items() if k != "Match"},
                }
            )
    return findings


def _redact(match: str) -> str:
    if not match:
        return ""
    if len(match) <= 8:
        return "*" * len(match)
    return match[:2] + "*" * (len(match) - 4) + match[-2:]
