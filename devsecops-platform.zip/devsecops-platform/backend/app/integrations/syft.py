"""
Normalizer for Syft's CycloneDX JSON SBOM output.

Produces:
  - the SBOM document (stored as-is in the `sboms` table for the SBOM viewer)
  - license "findings" (type=license) so the policy engine can gate on
    denied/unapproved licenses using the same Finding pipeline as everything else.
"""
from typing import Any


def extract_sbom_summary(report: dict[str, Any]) -> dict:
    components = report.get("components", [])
    return {"format": "CycloneDX", "component_count": len(components), "document": report}


def normalize_license_findings(report: dict[str, Any]) -> list[dict]:
    findings = []
    for component in report.get("components", []) or []:
        name = component.get("name", "unknown")
        version = component.get("version", "")
        for lic in component.get("licenses", []) or []:
            lic_id = (lic.get("license") or {}).get("id") or (lic.get("license") or {}).get("name")
            if not lic_id:
                continue
            findings.append(
                {
                    "type": "license",
                    "severity": "info",  # actual severity/blocking decided by policy engine, not the scanner
                    "tool": "syft",
                    "rule_id": lic_id,
                    "title": f"{name}@{version} — license {lic_id}",
                    "package_name": name,
                    "package_version": version,
                    "license_id": lic_id,
                    "raw": component,
                }
            )
    return findings
