from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field

from app.models.models import FindingStatus, FindingType, GateStatus, Role, Severity


# ---------- Auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: Optional[str] = None


class UserOut(BaseModel):
    id: str
    email: EmailStr
    full_name: Optional[str]
    role: Role
    is_active: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# ---------- Projects ----------
class ProjectCreate(BaseModel):
    name: str
    repo_full_name: str = Field(description="e.g. 'my-org/my-repo'")
    default_branch: str = "main"


class ProjectOut(BaseModel):
    id: str
    name: str
    repo_full_name: str
    default_branch: str
    is_demo: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Policy ----------
class PolicyUpdate(BaseModel):
    max_critical: Optional[int] = None
    max_high: Optional[int] = None
    max_medium: Optional[int] = None
    block_on_secrets: Optional[bool] = None
    denied_licenses: Optional[list[str]] = None
    allowed_licenses: Optional[list[str]] = None


class PolicyOut(BaseModel):
    id: str
    project_id: str
    max_critical: int
    max_high: int
    max_medium: int
    block_on_secrets: bool
    denied_licenses: list[str]
    allowed_licenses: list[str]
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Findings ----------
class FindingOut(BaseModel):
    id: str
    scan_id: str
    type: FindingType
    severity: Severity
    tool: str
    rule_id: Optional[str]
    title: str
    description: Optional[str]
    file_path: Optional[str]
    line_start: Optional[int]
    line_end: Optional[int]
    package_name: Optional[str]
    package_version: Optional[str]
    cve_id: Optional[str]
    license_id: Optional[str]
    redacted_secret_preview: Optional[str]
    status: FindingStatus
    created_at: datetime

    class Config:
        from_attributes = True


class FindingTriageUpdate(BaseModel):
    status: FindingStatus
    reason: Optional[str] = None


# ---------- Scans / ingestion ----------
class ScanIngestRequest(BaseModel):
    """
    Payload posted by the GitHub Actions workflow after running all scanners.
    `raw_reports` keys: 'semgrep', 'trivy_fs', 'trivy_image', 'trivy_config', 'gitleaks', 'syft'
    Each value is the raw JSON produced by that tool (already parsed).
    """
    repo_full_name: str
    commit_sha: str
    branch: str
    pr_number: Optional[int] = None
    raw_reports: dict[str, Any]


class ScanOut(BaseModel):
    id: str
    project_id: str
    commit_sha: str
    branch: str
    pr_number: Optional[int]
    gate_status: GateStatus
    gate_reason: Optional[str]
    started_at: datetime
    completed_at: Optional[datetime]

    class Config:
        from_attributes = True


class ScanDetailOut(ScanOut):
    findings: list[FindingOut]
    finding_counts: dict[str, int]


# ---------- Audit ----------
class AuditLogOut(BaseModel):
    id: str
    actor_label: str
    action: str
    entity_type: str
    entity_id: str
    details: Optional[dict]
    created_at: datetime

    class Config:
        from_attributes = True
