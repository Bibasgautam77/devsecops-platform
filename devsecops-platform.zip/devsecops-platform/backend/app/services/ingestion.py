"""
Ingestion service — the single place that turns a ScanIngestRequest into
Scan/Finding/Sbom rows and a gate decision.
"""
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.logging import get_logger
from app.integrations.gitleaks import normalize_gitleaks
from app.integrations.semgrep import normalize_semgrep
from app.integrations.syft import extract_sbom_summary, normalize_license_findings
from app.integrations.trivy import normalize_trivy
from app.models import models
from app.policy.gate_engine import evaluate_gate

log = get_logger(__name__)


def get_or_create_project(db: Session, repo_full_name: str) -> models.Project:
    project = db.query(models.Project).filter_by(repo_full_name=repo_full_name).first()
    if project:
        return project
    project = models.Project(name=repo_full_name.split("/")[-1], repo_full_name=repo_full_name)
    db.add(project)
    db.flush()
    # every project gets a default policy row immediately
    from app.core.config import get_settings

    settings = get_settings()
    policy = models.Policy(
        project_id=project.id,
        max_critical=settings.DEFAULT_MAX_CRITICAL,
        max_high=settings.DEFAULT_MAX_HIGH,
        block_on_secrets=settings.DEFAULT_BLOCK_ON_SECRETS,
        denied_licenses=settings.DEFAULT_DENIED_LICENSES,
    )
    db.add(policy)
    db.flush()
    return project


def normalize_all_reports(raw_reports: dict) -> tuple[list[dict], dict | None]:
    """Returns (findings_as_dicts, sbom_summary_or_none)."""
    findings: list[dict] = []

    if "semgrep" in raw_reports:
        findings += normalize_semgrep(raw_reports["semgrep"])
    if "trivy_fs" in raw_reports:
        findings += normalize_trivy(raw_reports["trivy_fs"], scan_mode="sca")
    if "trivy_image" in raw_reports:
        findings += normalize_trivy(raw_reports["trivy_image"], scan_mode="container")
    if "trivy_config" in raw_reports:
        findings += normalize_trivy(raw_reports["trivy_config"], scan_mode="iac")
    if "gitleaks" in raw_reports:
        findings += normalize_gitleaks(raw_reports["gitleaks"])

    sbom_summary = None
    if "syft" in raw_reports:
        sbom_summary = extract_sbom_summary(raw_reports["syft"])
        findings += normalize_license_findings(raw_reports["syft"])

    return findings, sbom_summary


def ingest_scan(db: Session, payload) -> models.Scan:
    project = get_or_create_project(db, payload.repo_full_name)

    scan = models.Scan(
        project_id=project.id,
        commit_sha=payload.commit_sha,
        branch=payload.branch,
        pr_number=payload.pr_number,
        gate_status=models.GateStatus.pending,
    )
    db.add(scan)
    db.flush()

    findings_dicts, sbom_summary = normalize_all_reports(payload.raw_reports)

    for f in findings_dicts:
        db.add(models.Finding(scan_id=scan.id, **f))

    if sbom_summary:
        db.add(models.Sbom(scan_id=scan.id, **sbom_summary))

    db.flush()

    policy = project.policy
    decision = evaluate_gate(findings_dicts, policy)
    scan.gate_status = models.GateStatus(decision.status)
    scan.gate_reason = decision.reason
    scan.completed_at = datetime.now(timezone.utc)

    db.add(
        models.AuditLog(
            actor_label="system:ci-ingest",
            action="scan.ingested",
            entity_type="scan",
            entity_id=scan.id,
            details={"gate": decision.status, "counts": decision.counts, "reason": decision.reason},
        )
    )

    db.commit()
    db.refresh(scan)
    log.info("scan_ingested", project=project.repo_full_name, gate=decision.status, counts=decision.counts)
    return scan
