"""
Posts scan results back to GitHub as a Check Run + PR comment.

This is the ONLY place that talks to the GitHub API for write operations.
It requires the user's own GitHub App credentials (GITHUB_APP_ID +
GITHUB_APP_PRIVATE_KEY). If they are not configured, `report_scan_to_github`
raises GitHubNotConfiguredError rather than silently doing nothing — the
caller (API layer) turns this into an explicit HTTP 501 so nobody mistakes
"not configured" for "reported successfully".
"""
from github import Auth, Github, GithubIntegration

from app.core.config import get_settings
from app.core.logging import get_logger
from app.models import models

log = get_logger(__name__)


class GitHubNotConfiguredError(RuntimeError):
    pass


def _get_installation_client(repo_full_name: str) -> Github:
    settings = get_settings()
    if not settings.github_app_configured:
        raise GitHubNotConfiguredError(
            "GITHUB_APP_ID / GITHUB_APP_PRIVATE_KEY are not set. "
            "Configure your own GitHub App to enable PR reporting."
        )
    auth = Auth.AppAuth(settings.GITHUB_APP_ID, settings.GITHUB_APP_PRIVATE_KEY)
    integration = GithubIntegration(auth=auth)
    installation = integration.get_repo_installation(*repo_full_name.split("/"))
    return integration.get_github_for_installation(installation.id)


def build_summary_markdown(scan: models.Scan, findings: list[models.Finding]) -> str:
    from collections import Counter

    by_sev = Counter(f.severity.value for f in findings if f.status == models.FindingStatus.open)
    lines = [
        f"### DevSecOps Security Gate: {'✅ PASSED' if scan.gate_status == models.GateStatus.passed else '❌ FAILED'}",
        "",
        f"Commit `{scan.commit_sha[:8]}` on `{scan.branch}`",
        "",
        "| Severity | Count |",
        "|---|---|",
    ]
    for sev in ("critical", "high", "medium", "low", "info"):
        lines.append(f"| {sev} | {by_sev.get(sev, 0)} |")
    lines.append("")
    if scan.gate_reason:
        lines.append(f"**Reason:** {scan.gate_reason}")
    return "\n".join(lines)


def report_scan_to_github(repo_full_name: str, scan: models.Scan, findings: list[models.Finding]) -> None:
    client = _get_installation_client(repo_full_name)  # raises if not configured
    repo = client.get_repo(repo_full_name)
    summary = build_summary_markdown(scan, findings)

    conclusion = "success" if scan.gate_status == models.GateStatus.passed else "failure"
    repo.create_check_run(
        name="DevSecOps Security Gate",
        head_sha=scan.commit_sha,
        status="completed",
        conclusion=conclusion,
        output={"title": "Security Gate Result", "summary": summary},
    )

    if scan.pr_number:
        pr = repo.get_pull(scan.pr_number)
        pr.create_issue_comment(summary)

    log.info("github_reported", repo=repo_full_name, pr=scan.pr_number, conclusion=conclusion)
