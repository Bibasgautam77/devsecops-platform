from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jwt import PyJWTError
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import decode_token
from app.db.session import get_db
from app.models.models import Role, User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
settings = get_settings()


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token type")
        user_id = payload["sub"]
    except (PyJWTError, KeyError):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Could not validate credentials")

    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")
    return user


def require_role(*allowed: Role):
    def _checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Requires role in {[r.value for r in allowed]}")
        return user

    return _checker


def verify_ingest_key(x_ingest_key: str = Header(...)) -> None:
    """Shared-secret auth used only by the GitHub Actions CI job to push scan results."""
    if x_ingest_key != settings.INGEST_API_KEY:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid ingest API key")
