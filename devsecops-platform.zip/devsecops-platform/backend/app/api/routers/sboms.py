from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.session import get_db
from app.models.models import Sbom, User

router = APIRouter(prefix="/sboms", tags=["sboms"])


@router.get("/{scan_id}")
def get_sbom_for_scan(scan_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    sbom = db.query(Sbom).filter_by(scan_id=scan_id).first()
    if not sbom:
        raise HTTPException(404, "No SBOM recorded for this scan")
    return {
        "id": sbom.id,
        "scan_id": sbom.scan_id,
        "format": sbom.format,
        "component_count": sbom.component_count,
        "document": sbom.document,
    }
