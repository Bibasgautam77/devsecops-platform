from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_role
from app.core.config import get_settings
from app.db.session import get_db
from app.models.models import AuditLog, Policy, Project, Role, User
from app.schemas.schemas import ProjectCreate, ProjectOut

router = APIRouter(prefix="/projects", tags=["projects"])
settings = get_settings()


@router.get("", response_model=list[ProjectOut])
def list_projects(db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    return db.query(Project).order_by(Project.created_at.desc()).all()


@router.post("", response_model=ProjectOut, status_code=201)
def create_project(
    payload: ProjectCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_role(Role.admin, Role.maintainer)),
):
    if db.query(Project).filter_by(repo_full_name=payload.repo_full_name).first():
        raise HTTPException(400, "Project already connected")
    project = Project(**payload.model_dump())
    db.add(project)
    db.flush()
    db.add(
        Policy(
            project_id=project.id,
            max_critical=settings.DEFAULT_MAX_CRITICAL,
            max_high=settings.DEFAULT_MAX_HIGH,
            block_on_secrets=settings.DEFAULT_BLOCK_ON_SECRETS,
            denied_licenses=settings.DEFAULT_DENIED_LICENSES,
        )
    )
    db.add(
        AuditLog(
            actor_user_id=user.id,
            actor_label=f"user:{user.email}",
            action="project.created",
            entity_type="project",
            entity_id=project.id,
            details={"repo_full_name": project.repo_full_name},
        )
    )
    db.commit()
    db.refresh(project)
    return project


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(project_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project
