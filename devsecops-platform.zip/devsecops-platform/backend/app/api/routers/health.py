from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db

router = APIRouter(prefix="/health", tags=["health"])
settings = get_settings()


@router.get("")
def health():
    return {"status": "ok", "service": settings.APP_NAME, "environment": settings.ENVIRONMENT}


@router.get("/db")
def health_db(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok", "component": "database"}


@router.get("/github")
def health_github():
    return {
        "configured": settings.github_app_configured,
        "message": "GitHub App configured" if settings.github_app_configured
        else "GitHub App not configured — PR reporting endpoints will return 501 until "
             "GITHUB_APP_ID and GITHUB_APP_PRIVATE_KEY are set.",
    }
