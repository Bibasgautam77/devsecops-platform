from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import require_role
from app.db.session import get_db
from app.models.models import AuditLog, Role, User
from app.schemas.schemas import AuditLogOut

router = APIRouter(prefix="/audit-log", tags=["audit"])


@router.get("", response_model=list[AuditLogOut])
def list_audit_log(
    entity_type: str | None = None,
    entity_id: str | None = None,
    db: Session = Depends(get_db),
    _user: User = Depends(require_role(Role.admin, Role.maintainer)),
):
    q = db.query(AuditLog)
    if entity_type:
        q = q.filter_by(entity_type=entity_type)
    if entity_id:
        q = q.filter_by(entity_id=entity_id)
    return q.order_by(AuditLog.created_at.desc()).limit(500).all()
