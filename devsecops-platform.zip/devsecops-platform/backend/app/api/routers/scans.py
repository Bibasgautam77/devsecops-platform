from collections import Counter

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, verify_ingest_key
from app.db.session import get_db
from app.models.models import Project, Scan, User
from app.schemas.schemas import ScanDetailOut, ScanIngestRequest, ScanOut
from app.services.github_reporting import GitHubNotConfiguredError, report_scan_to_github
from app.services.ingestion import ingest_scan

router = APIRouter(prefix="/scans", tags=["scans"])


@router.post("/ingest", response_model=ScanOut, status_code=201)
def ingest(
    payload: ScanIngestRequest,
    db: Session = Depends(get_db),
    _: None = Depends(verify_ingest_key),
):
    """
    Called by the GitHub Actions workflow (.github/workflows/security-ci.yml)
    with the raw JSON output of Semgrep/Trivy/Gitleaks/Syft for one commit/PR.
    Authenticated via the X-Ingest-Key header (shared secret), not user JWTs,
    since this is a machine-to-machine CI call.
    """
    scan = ingest_scan(db, payload)
    return scan


@router.get("", response_model=list[ScanOut])
def list_scans(
    project_id: str | None = None,
    db: Session = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    q = db.query(Scan)
    if project_id:
        q = q.filter_by(project_id=project_id)
    return q.order_by(Scan.started_at.desc()).limit(200).all()


@router.get("/{scan_id}", response_model=ScanDetailOut)
def get_scan(scan_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    scan = db.get(Scan, scan_id)
    if not scan:
        raise HTTPException(404, "Scan not found")
    counts = Counter(f.severity.value for f in scan.findings if f.status.value == "open")
    return ScanDetailOut(
        **ScanOut.model_validate(scan).model_dump(),
        findings=scan.findings,
        finding_counts=dict(counts),
    )


@router.post("/{scan_id}/report-to-github", status_code=202)
def report_to_github(scan_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    scan = db.get(Scan, scan_id)
    if not scan:
        raise HTTPException(404, "Scan not found")
    project = db.get(Project, scan.project_id)
    try:
        report_scan_to_github(project.repo_full_name, scan, scan.findings)
    except GitHubNotConfiguredError as e:
        raise HTTPException(501, str(e))
    return {"status": "reported"}
