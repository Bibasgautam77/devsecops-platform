from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_role
from app.db.session import get_db
from app.models.models import AuditLog, Finding, Role, User
from app.schemas.schemas import FindingOut, FindingTriageUpdate

router = APIRouter(prefix="/findings", tags=["findings"])


@router.get("", response_model=list[FindingOut])
def list_findings(
    scan_id: str | None = None,
    status: str | None = None,
    severity: str | None = None,
    type: str | None = None,
    db: Session = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    q = db.query(Finding)
    if scan_id:
        q = q.filter_by(scan_id=scan_id)
    if status:
        q = q.filter_by(status=status)
    if severity:
        q = q.filter_by(severity=severity)
    if type:
        q = q.filter_by(type=type)
    return q.order_by(Finding.created_at.desc()).limit(500).all()


@router.patch("/{finding_id}/triage", response_model=FindingOut)
def triage_finding(
    finding_id: str,
    payload: FindingTriageUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_role(Role.admin, Role.maintainer)),
):
    finding = db.get(Finding, finding_id)
    if not finding:
        raise HTTPException(404, "Finding not found")

    previous_status = finding.status
    finding.status = payload.status

    db.add(
        AuditLog(
            actor_user_id=user.id,
            actor_label=f"user:{user.email}",
            action="finding.triage",
            entity_type="finding",
            entity_id=finding.id,
            details={
                "from": previous_status.value,
                "to": payload.status.value,
                "reason": payload.reason,
            },
        )
    )
    db.commit()
    db.refresh(finding)
    return finding
