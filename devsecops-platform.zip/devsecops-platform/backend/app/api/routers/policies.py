from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_role
from app.db.session import get_db
from app.models.models import AuditLog, Policy, Project, Role, User
from app.schemas.schemas import PolicyOut, PolicyUpdate

router = APIRouter(prefix="/projects/{project_id}/policy", tags=["policy"])


@router.get("", response_model=PolicyOut)
def get_policy(project_id: str, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    policy = db.query(Policy).filter_by(project_id=project_id).first()
    if not policy:
        raise HTTPException(404, "Policy not found for project")
    return policy


@router.put("", response_model=PolicyOut)
def update_policy(
    project_id: str,
    payload: PolicyUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_role(Role.admin, Role.maintainer)),
):
    if not db.get(Project, project_id):
        raise HTTPException(404, "Project not found")
    policy = db.query(Policy).filter_by(project_id=project_id).first()
    if not policy:
        raise HTTPException(404, "Policy not found for project")

    updates = payload.model_dump(exclude_unset=True)
    for key, value in updates.items():
        setattr(policy, key, value)

    db.add(
        AuditLog(
            actor_user_id=user.id,
            actor_label=f"user:{user.email}",
            action="policy.updated",
            entity_type="policy",
            entity_id=policy.id,
            details=updates,
        )
    )
    db.commit()
    db.refresh(policy)
    return policy
