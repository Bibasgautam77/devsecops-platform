"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-09-26
"""
from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

role_enum = sa.Enum("admin", "maintainer", "viewer", name="role")
severity_enum = sa.Enum("critical", "high", "medium", "low", "info", name="severity")
finding_type_enum = sa.Enum("sast", "sca", "secret", "container", "iac", "license", name="findingtype")
finding_status_enum = sa.Enum(
    "open", "ignored", "false_positive", "accepted_risk", "resolved", name="findingstatus"
)
gate_status_enum = sa.Enum("pending", "passed", "failed", name="gatestatus")


def upgrade() -> None:
    bind = op.get_bind()
    role_enum.create(bind, checkfirst=True)
    severity_enum.create(bind, checkfirst=True)
    finding_type_enum.create(bind, checkfirst=True)
    finding_status_enum.create(bind, checkfirst=True)
    gate_status_enum.create(bind, checkfirst=True)

    op.create_table(
        "users",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("email", sa.String, nullable=False, unique=True),
        sa.Column("hashed_password", sa.String, nullable=False),
        sa.Column("full_name", sa.String, nullable=True),
        sa.Column("role", role_enum, nullable=False, server_default="viewer"),
        sa.Column("is_active", sa.Boolean, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_email", "users", ["email"])

    op.create_table(
        "projects",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("name", sa.String, nullable=False),
        sa.Column("repo_full_name", sa.String, nullable=False, unique=True),
        sa.Column("default_branch", sa.String, server_default="main"),
        sa.Column("is_demo", sa.Boolean, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "policies",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("project_id", sa.String, sa.ForeignKey("projects.id"), nullable=False, unique=True),
        sa.Column("max_critical", sa.Integer, server_default="0"),
        sa.Column("max_high", sa.Integer, server_default="5"),
        sa.Column("max_medium", sa.Integer, server_default="50"),
        sa.Column("block_on_secrets", sa.Boolean, server_default=sa.true()),
        sa.Column("denied_licenses", sa.JSON, nullable=True),
        sa.Column("allowed_licenses", sa.JSON, nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "scans",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("project_id", sa.String, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("commit_sha", sa.String, nullable=False),
        sa.Column("branch", sa.String, nullable=False),
        sa.Column("pr_number", sa.Integer, nullable=True),
        sa.Column("triggered_by", sa.String, server_default="github-actions"),
        sa.Column("gate_status", gate_status_enum, server_default="pending"),
        sa.Column("gate_reason", sa.Text, nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_scans_project_id", "scans", ["project_id"])
    op.create_index("ix_scans_commit_sha", "scans", ["commit_sha"])

    op.create_table(
        "findings",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("scan_id", sa.String, sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("type", finding_type_enum, nullable=False),
        sa.Column("severity", severity_enum, nullable=False),
        sa.Column("tool", sa.String, nullable=False),
        sa.Column("rule_id", sa.String, nullable=True),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("file_path", sa.String, nullable=True),
        sa.Column("line_start", sa.Integer, nullable=True),
        sa.Column("line_end", sa.Integer, nullable=True),
        sa.Column("package_name", sa.String, nullable=True),
        sa.Column("package_version", sa.String, nullable=True),
        sa.Column("cve_id", sa.String, nullable=True),
        sa.Column("license_id", sa.String, nullable=True),
        sa.Column("redacted_secret_preview", sa.String, nullable=True),
        sa.Column("secret_fingerprint", sa.String, nullable=True),
        sa.Column("status", finding_status_enum, server_default="open"),
        sa.Column("raw", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_findings_scan_id", "findings", ["scan_id"])
    op.create_index("ix_findings_severity", "findings", ["severity"])
    op.create_index("ix_findings_status", "findings", ["status"])
    op.create_index("ix_findings_type", "findings", ["type"])

    op.create_table(
        "sboms",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("scan_id", sa.String, sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("format", sa.String, server_default="CycloneDX"),
        sa.Column("component_count", sa.Integer, server_default="0"),
        sa.Column("document", sa.JSON, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_sboms_scan_id", "sboms", ["scan_id"])

    op.create_table(
        "audit_log",
        sa.Column("id", sa.String, primary_key=True),
        sa.Column("actor_user_id", sa.String, nullable=True),
        sa.Column("actor_label", sa.String, nullable=False),
        sa.Column("action", sa.String, nullable=False),
        sa.Column("entity_type", sa.String, nullable=False),
        sa.Column("entity_id", sa.String, nullable=False),
        sa.Column("details", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_audit_log_entity", "audit_log", ["entity_type", "entity_id"])


def downgrade() -> None:
    op.drop_table("audit_log")
    op.drop_table("sboms")
    op.drop_table("findings")
    op.drop_table("scans")
    op.drop_table("policies")
    op.drop_table("projects")
    op.drop_table("users")
    gate_status_enum.drop(op.get_bind(), checkfirst=True)
    finding_status_enum.drop(op.get_bind(), checkfirst=True)
    finding_type_enum.drop(op.get_bind(), checkfirst=True)
    severity_enum.drop(op.get_bind(), checkfirst=True)
    role_enum.drop(op.get_bind(), checkfirst=True)
