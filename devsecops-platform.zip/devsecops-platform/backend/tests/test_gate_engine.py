from types import SimpleNamespace

from app.policy.gate_engine import evaluate_gate


def make_policy(**overrides):
    defaults = dict(
        max_critical=0,
        max_high=5,
        max_medium=50,
        block_on_secrets=True,
        denied_licenses=["GPL-3.0"],
        allowed_licenses=[],
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def test_passes_with_no_findings():
    decision = evaluate_gate([], make_policy())
    assert decision.status == "passed"


def test_fails_on_critical_over_threshold():
    findings = [{"type": "sast", "severity": "critical", "status": "open"}]
    decision = evaluate_gate(findings, make_policy(max_critical=0))
    assert decision.status == "failed"
    assert "critical" in decision.reason


def test_ignores_triaged_findings():
    findings = [{"type": "sast", "severity": "critical", "status": "ignored"}]
    decision = evaluate_gate(findings, make_policy(max_critical=0))
    assert decision.status == "passed"


def test_blocks_on_secret_by_default():
    findings = [{"type": "secret", "severity": "critical", "status": "open"}]
    decision = evaluate_gate(findings, make_policy(block_on_secrets=True))
    assert decision.status == "failed"
    assert "secret" in decision.reason


def test_secret_allowed_when_block_on_secrets_false():
    findings = [{"type": "secret", "severity": "critical", "status": "open"}]
    decision = evaluate_gate(findings, make_policy(block_on_secrets=False, max_critical=99))
    assert decision.status == "passed"


def test_denied_license_fails_gate():
    findings = [
        {
            "type": "license",
            "severity": "info",
            "status": "open",
            "license_id": "GPL-3.0",
            "package_name": "some-lib",
        }
    ]
    decision = evaluate_gate(findings, make_policy(denied_licenses=["GPL-3.0"]))
    assert decision.status == "failed"
    assert "GPL-3.0" in decision.reason


def test_allow_list_rejects_unlisted_license():
    findings = [
        {
            "type": "license",
            "severity": "info",
            "status": "open",
            "license_id": "WTFPL",
            "package_name": "weird-lib",
        }
    ]
    decision = evaluate_gate(findings, make_policy(denied_licenses=[], allowed_licenses=["MIT", "Apache-2.0"]))
    assert decision.status == "failed"


def test_high_count_within_threshold_passes():
    findings = [{"type": "sast", "severity": "high", "status": "open"} for _ in range(3)]
    decision = evaluate_gate(findings, make_policy(max_high=5))
    assert decision.status == "passed"
    assert decision.counts["high"] == 3
