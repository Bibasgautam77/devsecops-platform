def auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def test_register_first_user_is_admin(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "first@test.com", "password": "SuperSecret123!"},
    )
    assert resp.status_code == 201
    assert resp.json()["role"] == "admin"


def test_second_user_is_viewer(client):
    client.post("/api/v1/auth/register", json={"email": "a@test.com", "password": "SuperSecret123!"})
    resp = client.post("/api/v1/auth/register", json={"email": "b@test.com", "password": "SuperSecret123!"})
    assert resp.json()["role"] == "viewer"


def test_login_wrong_password_rejected(client):
    client.post("/api/v1/auth/register", json={"email": "x@test.com", "password": "SuperSecret123!"})
    resp = client.post("/api/v1/auth/login", data={"username": "x@test.com", "password": "wrong"})
    assert resp.status_code == 401


def test_create_project_requires_auth(client):
    resp = client.post("/api/v1/projects", json={"name": "demo", "repo_full_name": "org/demo"})
    assert resp.status_code == 401


def test_create_and_list_project(client, admin_token):
    resp = client.post(
        "/api/v1/projects",
        json={"name": "demo", "repo_full_name": "org/demo"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 201
    resp = client.get("/api/v1/projects", headers=auth_headers(admin_token))
    assert len(resp.json()) == 1


def test_ingest_requires_ingest_key(client):
    resp = client.post(
        "/api/v1/scans/ingest",
        json={"repo_full_name": "org/demo", "commit_sha": "abc", "branch": "main", "raw_reports": {}},
    )
    assert resp.status_code == 422 or resp.status_code == 401  # missing header vs wrong key


def test_ingest_creates_project_and_scan_and_fails_gate_on_critical(client, admin_token):
    payload = {
        "repo_full_name": "org/auto-created",
        "commit_sha": "deadbeef",
        "branch": "main",
        "pr_number": 12,
        "raw_reports": {
            "semgrep": {
                "results": [
                    {
                        "check_id": "rule.critical",
                        "path": "app.py",
                        "start": {"line": 1},
                        "end": {"line": 1},
                        "extra": {"severity": "ERROR", "message": "bad"},
                    }
                ]
            }
        },
    }
    resp = client.post(
        "/api/v1/scans/ingest",
        json=payload,
        headers={"X-Ingest-Key": "CHANGE_ME_INGEST_KEY"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["gate_status"] == "failed"

    scan_id = body["id"]
    detail = client.get(f"/api/v1/scans/{scan_id}", headers=auth_headers(admin_token)).json()
    assert detail["finding_counts"]["critical"] == 1


def test_triage_finding_requires_maintainer_or_admin(client, admin_token):
    ingest_resp = client.post(
        "/api/v1/scans/ingest",
        json={
            "repo_full_name": "org/triage-test",
            "commit_sha": "c1",
            "branch": "main",
            "raw_reports": {
                "gitleaks": [
                    {"RuleID": "generic-api-key", "File": "a.py", "StartLine": 1, "EndLine": 1, "Secret": "abcdef123456"}
                ]
            },
        },
        headers={"X-Ingest-Key": "CHANGE_ME_INGEST_KEY"},
    )
    scan_id = ingest_resp.json()["id"]
    findings = client.get(f"/api/v1/findings?scan_id={scan_id}", headers=auth_headers(admin_token)).json()
    finding_id = findings[0]["id"]

    resp = client.patch(
        f"/api/v1/findings/{finding_id}/triage",
        json={"status": "false_positive", "reason": "test"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    assert resp.json()["status"] == "false_positive"

    audit = client.get("/api/v1/audit-log", headers=auth_headers(admin_token)).json()
    assert any(a["action"] == "finding.triage" for a in audit)


def test_report_to_github_returns_501_when_not_configured(client, admin_token):
    ingest_resp = client.post(
        "/api/v1/scans/ingest",
        json={"repo_full_name": "org/gh-test", "commit_sha": "c2", "branch": "main", "raw_reports": {}},
        headers={"X-Ingest-Key": "CHANGE_ME_INGEST_KEY"},
    )
    scan_id = ingest_resp.json()["id"]
    resp = client.post(f"/api/v1/scans/{scan_id}/report-to-github", headers=auth_headers(admin_token))
    assert resp.status_code == 501
