from app.integrations.gitleaks import normalize_gitleaks
from app.integrations.semgrep import normalize_semgrep
from app.integrations.syft import extract_sbom_summary, normalize_license_findings
from app.integrations.trivy import normalize_trivy


def test_normalize_semgrep_basic():
    report = {
        "results": [
            {
                "check_id": "python.lang.security.audit.exec-detected",
                "path": "app/utils.py",
                "start": {"line": 10},
                "end": {"line": 10},
                "extra": {"severity": "ERROR", "message": "Avoid exec()"},
            }
        ]
    }
    findings = normalize_semgrep(report)
    assert len(findings) == 1
    assert findings[0]["severity"] == "critical"
    assert findings[0]["type"] == "sast"
    assert findings[0]["file_path"] == "app/utils.py"


def test_normalize_trivy_sca_vulnerability():
    report = {
        "Results": [
            {
                "Target": "requirements.txt",
                "Vulnerabilities": [
                    {
                        "VulnerabilityID": "CVE-2024-1234",
                        "PkgName": "requests",
                        "InstalledVersion": "2.25.0",
                        "Severity": "HIGH",
                        "Description": "example",
                    }
                ],
            }
        ]
    }
    findings = normalize_trivy(report, scan_mode="sca")
    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["cve_id"] == "CVE-2024-1234"


def test_normalize_trivy_iac_misconfig():
    report = {
        "Results": [
            {
                "Target": "main.tf",
                "Misconfigurations": [
                    {"ID": "AVD-AWS-0001", "Title": "S3 bucket is public", "Severity": "CRITICAL"}
                ],
            }
        ]
    }
    findings = normalize_trivy(report, scan_mode="iac")
    assert findings[0]["type"] == "iac"
    assert findings[0]["severity"] == "critical"


def test_normalize_trivy_secret_is_redacted():
    report = {
        "Results": [
            {
                "Target": "config.py",
                "Secrets": [
                    {"RuleID": "aws-access-key", "Category": "AWS", "Severity": "HIGH", "Match": "AKIA1234567890ABCD"}
                ],
            }
        ]
    }
    findings = normalize_trivy(report, scan_mode="container")
    assert findings[0]["type"] == "secret"
    assert "AKIA1234567890ABCD" not in findings[0]["redacted_secret_preview"]
    assert "Match" not in findings[0]["raw"]


def test_normalize_gitleaks_redacts_and_fingerprints():
    report = [
        {
            "RuleID": "generic-api-key",
            "File": "settings.py",
            "StartLine": 5,
            "EndLine": 5,
            "Secret": "supersecretvalue123",
            "Description": "Generic API Key",
        }
    ]
    findings = normalize_gitleaks(report)
    assert len(findings) == 1
    f = findings[0]
    assert "supersecretvalue123" not in f["redacted_secret_preview"]
    assert f["secret_fingerprint"] is not None
    assert "Secret" not in f["raw"]


def test_syft_sbom_and_license_extraction():
    report = {
        "components": [
            {
                "name": "flask",
                "version": "3.0.0",
                "licenses": [{"license": {"id": "BSD-3-Clause"}}],
            },
            {
                "name": "some-gpl-lib",
                "version": "1.0.0",
                "licenses": [{"license": {"id": "GPL-3.0"}}],
            },
        ]
    }
    summary = extract_sbom_summary(report)
    assert summary["component_count"] == 2

    licenses = normalize_license_findings(report)
    assert len(licenses) == 2
    lic_ids = {f["license_id"] for f in licenses}
    assert lic_ids == {"BSD-3-Clause", "GPL-3.0"}
