# Entity-Relationship Diagram

```mermaid
erDiagram
    USERS ||--o{ AUDIT_LOG : "acts as"
    PROJECTS ||--|| POLICIES : "has one"
    PROJECTS ||--o{ SCANS : "has many"
    SCANS ||--o{ FINDINGS : "has many"
    SCANS ||--o{ SBOMS : "has (0 or 1 typically)"

    USERS {
        string id PK
        string email UK
        string hashed_password
        string full_name
        enum role "admin|maintainer|viewer"
        bool is_active
        datetime created_at
    }

    PROJECTS {
        string id PK
        string name
        string repo_full_name UK
        string default_branch
        bool is_demo
        datetime created_at
    }

    POLICIES {
        string id PK
        string project_id FK
        int max_critical
        int max_high
        int max_medium
        bool block_on_secrets
        json denied_licenses
        json allowed_licenses
        datetime updated_at
    }

    SCANS {
        string id PK
        string project_id FK
        string commit_sha
        string branch
        int pr_number "nullable"
        string triggered_by
        enum gate_status "pending|passed|failed"
        text gate_reason
        datetime started_at
        datetime completed_at
    }

    FINDINGS {
        string id PK
        string scan_id FK
        enum type "sast|sca|secret|container|iac|license"
        enum severity "critical|high|medium|low|info"
        string tool
        string rule_id
        string title
        text description
        string file_path
        int line_start
        int line_end
        string package_name
        string package_version
        string cve_id
        string license_id
        string redacted_secret_preview
        string secret_fingerprint
        enum status "open|ignored|false_positive|accepted_risk|resolved"
        json raw
        datetime created_at
    }

    SBOMS {
        string id PK
        string scan_id FK
        string format
        int component_count
        json document
        datetime created_at
    }

    AUDIT_LOG {
        string id PK
        string actor_user_id "nullable, FK-like"
        string actor_label
        string action
        string entity_type
        string entity_id
        json details
        datetime created_at
    }
```

## Indexing notes (see `alembic/versions/0001_initial.py`)

- `findings(scan_id)`, `findings(severity)`, `findings(status)`, `findings(type)` — the gate engine and
  dashboard filter on all four constantly.
- `scans(project_id)`, `scans(commit_sha)` — scan history lookups and re-ingestion idempotency checks.
- `audit_log(entity_type, entity_id)` — composite index for "show me the history of this finding/policy".
- `users(email)` unique index — login lookups.
