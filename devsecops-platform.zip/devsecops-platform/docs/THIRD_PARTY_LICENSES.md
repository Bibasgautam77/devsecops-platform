# Third-Party Licenses

This project's own source code is © Bibas Gautam, all rights reserved (see `LICENSE`). It builds on
and orchestrates the following open-source tools and libraries, each under its own license.
This platform does not claim ownership of any of them.

| Component | License | Project |
|---|---|---|
| Semgrep (CLI) | LGPL-2.1 (CLI); individual rules vary | https://github.com/semgrep/semgrep |
| Trivy | Apache-2.0 | https://github.com/aquasecurity/trivy |
| Gitleaks | MIT | https://github.com/gitleaks/gitleaks |
| Syft | Apache-2.0 | https://github.com/anchore/syft |
| FastAPI | MIT | https://github.com/tiangolo/fastapi |
| SQLAlchemy | MIT | https://www.sqlalchemy.org |
| Alembic | MIT | https://alembic.sqlalchemy.org |
| Pydantic | MIT | https://github.com/pydantic/pydantic |
| PyGithub | LGPL-3.0 | https://github.com/PyGithub/PyGithub |
| PyJWT | MIT | https://github.com/jpadilla/pyjwt |
| Passlib | BSD | https://passlib.readthedocs.io |
| Next.js | MIT | https://github.com/vercel/next.js |
| React | MIT | https://github.com/facebook/react |
| Tailwind CSS | MIT | https://github.com/tailwindlabs/tailwindcss |
| PostgreSQL | PostgreSQL License | https://www.postgresql.org |
| Docker | Apache-2.0 (Engine) | https://www.docker.com |

Verify current license terms directly with each upstream project before redistribution, as licenses
and versions may change over time.
