# Threat Model — DevSecOps Supply-Chain Platform

Methodology: STRIDE, applied per component of the architecture in the README.

## 1. Assets

- Source code / repo metadata submitted for scanning
- Scan findings (may reference CVEs, file paths, package names)
- **Secret fingerprints/redacted previews** (never raw secrets)
- GitHub App private key (if configured)
- User credentials (hashed) and JWTs
- Policy configuration (defines what "safe to release" means for the org)
- Audit log (must be tamper-evident / append-only in practice)

## 2. Trust boundaries

```
[Developer laptop] --push/PR--> [GitHub] --Actions runner--> [Ingest API] --> [DB]
                                                                  ^
                                                    [Dashboard user] --JWT--> [API]
```

1. **GitHub Actions runner → Ingest API**: authenticated via a shared secret (`INGEST_API_KEY`),
   not a user JWT. This is a machine credential with a single capability: create scans/findings.
2. **Dashboard user → API**: authenticated via JWT (access + refresh), RBAC-scoped (admin/maintainer/viewer).
3. **API → GitHub**: only for posting Check Runs/PR comments, using a GitHub App installation token
   scoped to Checks (write) and Pull Requests (write) only — never broader `repo` scope.

## 3. STRIDE analysis (by component)

| Component | Threat | Mitigation |
|---|---|---|
| Ingest endpoint | **Spoofing** — forged scan results from a non-CI source | `X-Ingest-Key` shared secret; rotate via `.env`; consider mTLS or IP allowlisting the runner in production |
| Ingest endpoint | **Tampering** — inflated/deflated finding counts to force a gate pass | Raw scanner JSON is stored (`raw` JSONB) for later audit; gate decision itself is recomputed server-side, never trusted from the CI payload |
| Findings storage | **Information disclosure** — raw secret values in DB/logs | Gitleaks/Trivy-secret normalizers strip the raw match before it ever reaches a DB row; only `redacted_secret_preview` + SHA-256 fingerprint stored; structured logger never logs `raw` finding payloads containing `Match`/`Secret` keys |
| Findings triage | **Repudiation** — a maintainer marks a critical finding as false-positive to force a release | Every triage action writes an immutable `AuditLog` row with actor, from/to status, and free-text reason |
| Auth | **Elevation of privilege** — viewer performs admin actions | All mutating endpoints (`policy.update`, `finding.triage`, `project.create`) require `require_role(admin, maintainer)`; viewers are read-only |
| GitHub reporting | **Spoofing** — posting fake Check Runs to an unrelated repo | GitHub App installation tokens are scoped per-installation by GitHub itself; the platform cannot post to a repo it wasn't installed on |
| Dashboard | **Tampering** — XSS via a scanner finding's `title`/`description` fields | React auto-escapes all interpolated text; no `dangerouslySetInnerHTML` is used anywhere in the frontend |
| Transport | **Information disclosure** — credentials/tokens over plaintext | Deployment guidance (README) mandates TLS termination (reverse proxy) in front of both services in any non-local environment |
| Denial of service | Ingest endpoint flooded with huge payloads | `payload.raw_reports` size should be bounded by a reverse-proxy body-size limit in production (documented in README troubleshooting); not enforced in this reference implementation |

## 4. Out of scope for this platform (by design)

- Scanning any repository the operator has not explicitly connected/authorized
- Any form of automated exploitation, penetration testing, or offensive security action
- Automatic merge/deploy on gate pass — the gate produces a status; humans/CI still control merge

## 5. Residual risks / recommendations for production hardening

- Add rate limiting to `/auth/login` and `/scans/ingest`.
- Rotate `JWT_SECRET_KEY` and `INGEST_API_KEY` regularly; store in a secrets manager, not `.env`, in production.
- Consider short-lived, per-workflow-run ingest tokens (e.g. minted via a signed GitHub OIDC token)
  instead of a single static `INGEST_API_KEY`, for stronger non-repudiation.
- Add database-level row-level security or a separate read-replica for audit-log export if compliance
  requires WORM (write-once-read-many) guarantees stronger than application-level immutability.
