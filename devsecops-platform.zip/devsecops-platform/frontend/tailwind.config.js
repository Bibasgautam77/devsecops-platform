/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        critical: "#dc2626",
        high: "#ea580c",
        medium: "#ca8a04",
        low: "#2563eb",
        info: "#64748b",
        pass: "#16a34a",
        fail: "#dc2626",
      },
    },
  },
  plugins: [],
};
