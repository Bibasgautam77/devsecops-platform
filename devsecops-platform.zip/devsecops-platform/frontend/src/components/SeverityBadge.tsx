const COLORS: Record<string, string> = {
  critical: "bg-red-950 text-red-400 border border-red-800",
  high: "bg-orange-950 text-orange-400 border border-orange-800",
  medium: "bg-yellow-950 text-yellow-400 border border-yellow-800",
  low: "bg-blue-950 text-blue-400 border border-blue-800",
  info: "bg-slate-800 text-slate-400 border border-slate-700",
};

export default function SeverityBadge({ severity }: { severity: string }) {
  return <span className={`badge ${COLORS[severity] || COLORS.info}`}>{severity}</span>;
}
