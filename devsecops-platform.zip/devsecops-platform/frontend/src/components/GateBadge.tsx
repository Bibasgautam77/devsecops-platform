const STYLES: Record<string, string> = {
  passed: "bg-green-950 text-green-400 border border-green-800",
  failed: "bg-red-950 text-red-400 border border-red-800",
  pending: "bg-slate-800 text-slate-400 border border-slate-700",
};

const LABELS: Record<string, string> = {
  passed: "✓ Gate Passed",
  failed: "✗ Gate Failed",
  pending: "… Pending",
};

export default function GateBadge({ status }: { status: string }) {
  return <span className={`badge ${STYLES[status] || STYLES.pending}`}>{LABELS[status] || status}</span>;
}
