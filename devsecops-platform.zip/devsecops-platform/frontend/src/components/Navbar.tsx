"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { clearToken } from "@/lib/api";

export default function Navbar() {
  const router = useRouter();

  function logout() {
    clearToken();
    router.push("/login");
  }

  return (
    <nav className="border-b border-[#232a3b] px-6 py-4 flex items-center justify-between">
      <Link href="/projects" className="font-semibold text-lg tracking-tight">
        🛡️ DevSecOps Platform
      </Link>
      <div className="flex items-center gap-6 text-sm text-slate-400">
        <Link href="/projects" className="hover:text-white">
          Projects
        </Link>
        <Link href="/audit-log" className="hover:text-white">
          Audit Log
        </Link>
        <button onClick={logout} className="hover:text-white">
          Log out
        </button>
      </div>
    </nav>
  );
}
