"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import GateBadge from "@/components/GateBadge";
import SeverityBadge from "@/components/SeverityBadge";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { api, ScanDetail, Finding, ApiError } from "@/lib/api";

const STATUS_OPTIONS = ["open", "ignored", "false_positive", "accepted_risk", "resolved"];

export default function ScanDetailPage() {
  const ready = useRequireAuth();
  const params = useParams<{ id: string }>();
  const [scan, setScan] = useState<ScanDetail | null>(null);
  const [sbom, setSbom] = useState<{ component_count: number } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<string>("");

  async function load() {
    const detail = await api.getScan(params.id);
    setScan(detail);
    try {
      const s = await api.getSbom(params.id);
      setSbom(s);
    } catch {
      setSbom(null); // no SBOM recorded for this scan — not an error
    }
  }

  useEffect(() => {
    if (ready) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, params.id]);

  async function triage(finding: Finding, status: string) {
    await api.triageFinding(finding.id, status);
    load();
  }

  async function reportToGithub() {
    setNotice(null);
    try {
      await api.reportToGithub(params.id);
      setNotice("Reported to GitHub successfully.");
    } catch (err) {
      setNotice(
        err instanceof ApiError && err.status === 501
          ? "GitHub App is not configured on this server, so nothing was posted. Set GITHUB_APP_ID / GITHUB_APP_PRIVATE_KEY to enable PR reporting."
          : "Failed to report to GitHub."
      );
    }
  }

  if (!ready || !scan) return null;

  const findings = filterType ? scan.findings.filter((f) => f.type === filterType) : scan.findings;
  const types = Array.from(new Set(scan.findings.map((f) => f.type)));

  return (
    <div>
      <Navbar />
      <main className="max-w-5xl mx-auto p-6 space-y-6">
        <div className="card p-5 flex items-center justify-between">
          <div>
            <div className="font-mono">{scan.commit_sha}</div>
            <div className="text-xs text-slate-500">
              {scan.branch}
              {scan.pr_number ? ` · PR #${scan.pr_number}` : ""}
            </div>
            {scan.gate_reason && <div className="text-xs text-slate-400 mt-2 max-w-lg">{scan.gate_reason}</div>}
          </div>
          <div className="flex flex-col items-end gap-2">
            <GateBadge status={scan.gate_status} />
            <button onClick={reportToGithub} className="text-xs bg-[#232a3b] hover:bg-[#2c3448] rounded px-3 py-1.5">
              Report to GitHub
            </button>
          </div>
        </div>

        {notice && <p className="text-sm text-yellow-400">{notice}</p>}

        <div className="grid grid-cols-5 gap-3">
          {Object.entries(scan.finding_counts).map(([sev, count]) => (
            <div key={sev} className="card p-3 text-center">
              <div className="text-2xl font-semibold">{count}</div>
              <SeverityBadge severity={sev} />
            </div>
          ))}
        </div>

        {sbom && (
          <div className="card p-4 text-sm text-slate-300">
            📦 SBOM recorded: <strong>{sbom.component_count}</strong> components (CycloneDX)
          </div>
        )}

        <div className="flex gap-2 text-xs">
          <button
            onClick={() => setFilterType("")}
            className={`px-3 py-1 rounded ${!filterType ? "bg-blue-600" : "bg-[#232a3b]"}`}
          >
            All ({scan.findings.length})
          </button>
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1 rounded ${filterType === t ? "bg-blue-600" : "bg-[#232a3b]"}`}
            >
              {t} ({scan.findings.filter((f) => f.type === t).length})
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {findings.map((f) => (
            <div key={f.id} className="card p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <SeverityBadge severity={f.severity} />
                    <span className="text-xs text-slate-500 uppercase">{f.tool}</span>
                  </div>
                  <div className="text-sm font-medium truncate">{f.title}</div>
                  {f.file_path && (
                    <div className="text-xs text-slate-500 font-mono">
                      {f.file_path}
                      {f.line_start ? `:${f.line_start}` : ""}
                    </div>
                  )}
                  {f.redacted_secret_preview && (
                    <div className="text-xs text-slate-500 font-mono">match: {f.redacted_secret_preview}</div>
                  )}
                </div>
                <select
                  value={f.status}
                  onChange={(e) => triage(f, e.target.value)}
                  className="bg-[#0b0f19] border border-[#232a3b] rounded px-2 py-1 text-xs"
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
          {findings.length === 0 && <p className="text-sm text-slate-400">No findings in this category.</p>}
        </div>
      </main>
    </div>
  );
}
