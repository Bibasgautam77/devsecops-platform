"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { api, Project, ApiError } from "@/lib/api";

export default function ProjectsPage() {
  const ready = useRequireAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [repo, setRepo] = useState("");

  async function load() {
    setLoading(true);
    try {
      setProjects(await api.listProjects());
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load projects");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (ready) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  async function handleConnect(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.createProject(name, repo);
      setName("");
      setRepo("");
      setShowForm(false);
      load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to connect project");
    }
  }

  if (!ready) return null;

  return (
    <div>
      <Navbar />
      <main className="max-w-5xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold">Connected Projects</h1>
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-600 hover:bg-blue-500 rounded px-4 py-2 text-sm"
          >
            + Connect Repository
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleConnect} className="card p-4 flex gap-3 items-end">
            <div className="flex-1">
              <label className="text-xs text-slate-400">Display name</label>
              <input
                required
                className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="my-service"
              />
            </div>
            <div className="flex-1">
              <label className="text-xs text-slate-400">GitHub repo (org/repo)</label>
              <input
                required
                className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm"
                value={repo}
                onChange={(e) => setRepo(e.target.value)}
                placeholder="my-org/my-service"
              />
            </div>
            <button type="submit" className="bg-green-700 hover:bg-green-600 rounded px-4 py-2 text-sm">
              Save
            </button>
          </form>
        )}

        {error && <p className="text-sm text-red-400">{error}</p>}
        {loading ? (
          <p className="text-sm text-slate-400">Loading…</p>
        ) : projects.length === 0 ? (
          <p className="text-sm text-slate-400">
            No projects yet. Connect a repository above, or run the seed script for demo data.
          </p>
        ) : (
          <div className="grid gap-3">
            {projects.map((p) => (
              <Link
                key={p.id}
                href={`/projects/${p.id}`}
                className="card p-4 flex items-center justify-between hover:border-blue-700 transition-colors"
              >
                <div>
                  <div className="font-medium">
                    {p.name}
                    {p.is_demo && (
                      <span className="ml-2 badge bg-slate-800 text-slate-400 border border-slate-700">demo</span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500">{p.repo_full_name}</div>
                </div>
                <span className="text-xs text-slate-500">default: {p.default_branch}</span>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
