"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import GateBadge from "@/components/GateBadge";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { api, Scan } from "@/lib/api";

export default function ProjectDetailPage() {
  const ready = useRequireAuth();
  const params = useParams<{ id: string }>();
  const [scans, setScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!ready) return;
    api
      .listScans(params.id)
      .then(setScans)
      .finally(() => setLoading(false));
  }, [ready, params.id]);

  if (!ready) return null;

  return (
    <div>
      <Navbar />
      <main className="max-w-5xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold">Scan History</h1>
          <Link
            href={`/projects/${params.id}/policy`}
            className="text-sm bg-[#232a3b] hover:bg-[#2c3448] rounded px-4 py-2"
          >
            ⚙ Policy Configuration
          </Link>
        </div>

        {loading ? (
          <p className="text-sm text-slate-400">Loading…</p>
        ) : scans.length === 0 ? (
          <p className="text-sm text-slate-400">
            No scans yet. Push a commit — the Security CI workflow will submit results here automatically.
          </p>
        ) : (
          <div className="grid gap-3">
            {scans.map((s) => (
              <Link
                key={s.id}
                href={`/scans/${s.id}`}
                className="card p-4 flex items-center justify-between hover:border-blue-700 transition-colors"
              >
                <div>
                  <div className="font-mono text-sm">{s.commit_sha.slice(0, 10)}</div>
                  <div className="text-xs text-slate-500">
                    {s.branch}
                    {s.pr_number ? ` · PR #${s.pr_number}` : ""} ·{" "}
                    {new Date(s.started_at).toLocaleString()}
                  </div>
                </div>
                <GateBadge status={s.gate_status} />
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
