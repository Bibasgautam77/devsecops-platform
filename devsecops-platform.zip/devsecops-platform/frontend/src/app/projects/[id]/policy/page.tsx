"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { api, Policy, ApiError } from "@/lib/api";

export default function PolicyPage() {
  const ready = useRequireAuth();
  const params = useParams<{ id: string }>();
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [deniedInput, setDeniedInput] = useState("");
  const [allowedInput, setAllowedInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!ready) return;
    api.getPolicy(params.id).then((p) => {
      setPolicy(p);
      setDeniedInput(p.denied_licenses.join(", "));
      setAllowedInput(p.allowed_licenses.join(", "));
    });
  }, [ready, params.id]);

  if (!ready || !policy) return null;

  async function save() {
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const updated = await api.updatePolicy(params.id, {
        max_critical: policy!.max_critical,
        max_high: policy!.max_high,
        max_medium: policy!.max_medium,
        block_on_secrets: policy!.block_on_secrets,
        denied_licenses: deniedInput.split(",").map((s) => s.trim()).filter(Boolean),
        allowed_licenses: allowedInput.split(",").map((s) => s.trim()).filter(Boolean),
      });
      setPolicy(updated);
      setSaved(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to save policy");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <Navbar />
      <main className="max-w-2xl mx-auto p-6 space-y-6">
        <h1 className="text-lg font-semibold">Release Gate Policy</h1>
        <p className="text-sm text-slate-400">
          These thresholds decide whether a scan's security gate passes or fails. Only findings
          with status "open" (not triaged) count toward these limits.
        </p>

        <div className="card p-6 space-y-5">
          <div className="grid grid-cols-3 gap-4">
            <NumberField
              label="Max critical findings"
              value={policy.max_critical}
              onChange={(v) => setPolicy({ ...policy, max_critical: v })}
            />
            <NumberField
              label="Max high findings"
              value={policy.max_high}
              onChange={(v) => setPolicy({ ...policy, max_high: v })}
            />
            <NumberField
              label="Max medium findings"
              value={policy.max_medium}
              onChange={(v) => setPolicy({ ...policy, max_medium: v })}
            />
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={policy.block_on_secrets}
              onChange={(e) => setPolicy({ ...policy, block_on_secrets: e.target.checked })}
            />
            Block the release gate on ANY unresolved secret finding
          </label>

          <div>
            <label className="text-xs text-slate-400">Denied licenses (comma-separated SPDX IDs)</label>
            <input
              className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm mt-1"
              value={deniedInput}
              onChange={(e) => setDeniedInput(e.target.value)}
              placeholder="GPL-3.0, AGPL-3.0"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400">
              Allow-list (optional — if set, any license NOT in this list fails the gate)
            </label>
            <input
              className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm mt-1"
              value={allowedInput}
              onChange={(e) => setAllowedInput(e.target.value)}
              placeholder="MIT, Apache-2.0, BSD-3-Clause"
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}
          {saved && <p className="text-sm text-green-400">Policy saved.</p>}

          <button
            onClick={save}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded px-4 py-2 text-sm"
          >
            {saving ? "Saving…" : "Save Policy"}
          </button>
        </div>
      </main>
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <label className="text-xs text-slate-400">{label}</label>
      <input
        type="number"
        min={0}
        className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm mt-1"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value || "0", 10))}
      />
    </div>
  );
}
