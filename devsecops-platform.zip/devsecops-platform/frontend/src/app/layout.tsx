import type { Metadata } from "next";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: "DevSecOps Supply-Chain Platform",
  description: "SAST, SCA, secrets, SBOM, container & IaC scanning with policy gates",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
