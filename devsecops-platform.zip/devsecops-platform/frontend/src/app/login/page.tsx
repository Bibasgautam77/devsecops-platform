"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, setToken, ApiError } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"login" | "register">("login");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "register") {
        await api.register(email, password, fullName);
      }
      const { access_token } = await api.login(email, password);
      setToken(access_token);
      router.push("/projects");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={handleSubmit} className="card w-full max-w-sm p-8 space-y-4">
        <h1 className="text-xl font-semibold">🛡️ DevSecOps Platform</h1>
        <p className="text-sm text-slate-400">
          {mode === "login" ? "Sign in to your account" : "Create the first admin account"}
        </p>

        {mode === "register" && (
          <input
            className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm"
            placeholder="Full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
        )}
        <input
          type="email"
          required
          className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          required
          minLength={8}
          className="w-full bg-[#0b0f19] border border-[#232a3b] rounded px-3 py-2 text-sm"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={busy}
          className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded py-2 text-sm font-medium"
        >
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Register & sign in"}
        </button>

        <button
          type="button"
          className="w-full text-xs text-slate-400 hover:text-white"
          onClick={() => setMode(mode === "login" ? "register" : "login")}
        >
          {mode === "login" ? "First time? Create the admin account" : "Already have an account? Sign in"}
        </button>

        <p className="text-xs text-slate-500 pt-2 border-t border-[#232a3b]">
          Demo credentials (after seeding): <code>admin@example.com</code> / <code>ChangeMe123!</code>
        </p>
      </form>
    </div>
  );
}
