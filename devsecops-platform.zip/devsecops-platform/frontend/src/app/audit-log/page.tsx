"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { api, AuditEntry } from "@/lib/api";

export default function AuditLogPage() {
  const ready = useRequireAuth();
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!ready) return;
    api
      .listAuditLog()
      .then(setEntries)
      .finally(() => setLoading(false));
  }, [ready]);

  if (!ready) return null;

  return (
    <div>
      <Navbar />
      <main className="max-w-5xl mx-auto p-6 space-y-4">
        <h1 className="text-lg font-semibold">Audit Log</h1>
        <p className="text-sm text-slate-400">
          Immutable record of every policy change, finding triage decision, project connection, and
          system scan ingestion.
        </p>

        {loading ? (
          <p className="text-sm text-slate-400">Loading…</p>
        ) : (
          <div className="card divide-y divide-[#232a3b]">
            {entries.map((e) => (
              <div key={e.id} className="p-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{e.action}</span>
                  <span className="text-xs text-slate-500">{new Date(e.created_at).toLocaleString()}</span>
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {e.actor_label} → {e.entity_type} #{e.entity_id.slice(0, 8)}
                </div>
                {e.details && (
                  <pre className="text-xs text-slate-600 mt-2 overflow-x-auto">
                    {JSON.stringify(e.details, null, 2)}
                  </pre>
                )}
              </div>
            ))}
            {entries.length === 0 && <p className="p-4 text-sm text-slate-400">No audit entries yet.</p>}
          </div>
        )}
      </main>
    </div>
  );
}
