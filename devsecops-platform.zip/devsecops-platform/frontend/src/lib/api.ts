/**
 * Thin fetch wrapper around the DevSecOps backend API.
 * Token is stored in localStorage under 'devsecops_token' (client-side only).
 * This is a demo-grade token store; a production deployment behind SSO
 * should swap this for httpOnly cookies issued by a backend session layer.
 */

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000/api/v1";

export type Role = "admin" | "maintainer" | "viewer";

export interface User {
  id: string;
  email: string;
  full_name: string | null;
  role: Role;
  is_active: boolean;
}

export interface Project {
  id: string;
  name: string;
  repo_full_name: string;
  default_branch: string;
  is_demo: boolean;
  created_at: string;
}

export interface Policy {
  id: string;
  project_id: string;
  max_critical: number;
  max_high: number;
  max_medium: number;
  block_on_secrets: boolean;
  denied_licenses: string[];
  allowed_licenses: string[];
  updated_at: string;
}

export interface Finding {
  id: string;
  scan_id: string;
  type: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  tool: string;
  rule_id: string | null;
  title: string;
  description: string | null;
  file_path: string | null;
  line_start: number | null;
  line_end: number | null;
  package_name: string | null;
  package_version: string | null;
  cve_id: string | null;
  license_id: string | null;
  redacted_secret_preview: string | null;
  status: "open" | "ignored" | "false_positive" | "accepted_risk" | "resolved";
  created_at: string;
}

export interface Scan {
  id: string;
  project_id: string;
  commit_sha: string;
  branch: string;
  pr_number: number | null;
  gate_status: "pending" | "passed" | "failed";
  gate_reason: string | null;
  started_at: string;
  completed_at: string | null;
}

export interface ScanDetail extends Scan {
  findings: Finding[];
  finding_counts: Record<string, number>;
}

export interface AuditEntry {
  id: string;
  actor_label: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: Record<string, unknown> | null;
  created_at: string;
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("devsecops_token");
}

export function setToken(token: string) {
  window.localStorage.setItem("devsecops_token", token);
}

export function clearToken() {
  window.localStorage.removeItem("devsecops_token");
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json();
}

export const api = {
  async login(email: string, password: string): Promise<{ access_token: string }> {
    const form = new URLSearchParams();
    form.set("username", email);
    form.set("password", password);
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    });
    if (!res.ok) throw new ApiError(res.status, "Invalid email or password");
    return res.json();
  },

  register(email: string, password: string, full_name?: string): Promise<User> {
    return request("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, full_name }),
    });
  },

  listProjects: (): Promise<Project[]> => request("/projects"),
  createProject: (name: string, repo_full_name: string): Promise<Project> =>
    request("/projects", { method: "POST", body: JSON.stringify({ name, repo_full_name }) }),

  getPolicy: (projectId: string): Promise<Policy> => request(`/projects/${projectId}/policy`),
  updatePolicy: (projectId: string, patch: Partial<Policy>): Promise<Policy> =>
    request(`/projects/${projectId}/policy`, { method: "PUT", body: JSON.stringify(patch) }),

  listScans: (projectId?: string): Promise<Scan[]> =>
    request(`/scans${projectId ? `?project_id=${projectId}` : ""}`),
  getScan: (scanId: string): Promise<ScanDetail> => request(`/scans/${scanId}`),
  reportToGithub: (scanId: string): Promise<{ status: string }> =>
    request(`/scans/${scanId}/report-to-github`, { method: "POST" }),

  listFindings: (params: Record<string, string> = {}): Promise<Finding[]> => {
    const qs = new URLSearchParams(params).toString();
    return request(`/findings${qs ? `?${qs}` : ""}`);
  },
  triageFinding: (findingId: string, status: string, reason?: string): Promise<Finding> =>
    request(`/findings/${findingId}/triage`, {
      method: "PATCH",
      body: JSON.stringify({ status, reason }),
    }),

  getSbom: (scanId: string): Promise<{ component_count: number; document: unknown }> =>
    request(`/sboms/${scanId}`),

  listAuditLog: (): Promise<AuditEntry[]> => request("/audit-log"),
};

export { ApiError };
