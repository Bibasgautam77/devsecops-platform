import { describe, expect, it } from "vitest";

// Small pure helper mirrored from dashboard logic, tested in isolation
// (kept here rather than importing the React component to avoid needing a
// DOM test environment for a simple ordering check).
const SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"];

function sortBySeverity<T extends { severity: string }>(items: T[]): T[] {
  return [...items].sort(
    (a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity)
  );
}

describe("sortBySeverity", () => {
  it("orders critical before low", () => {
    const input = [{ severity: "low" }, { severity: "critical" }, { severity: "medium" }];
    const sorted = sortBySeverity(input);
    expect(sorted[0].severity).toBe("critical");
    expect(sorted[sorted.length - 1].severity).toBe("low");
  });

  it("is stable for equal severities", () => {
    const input = [
      { severity: "high", id: 1 },
      { severity: "high", id: 2 },
    ];
    const sorted = sortBySeverity(input);
    expect(sorted.map((i) => i.id)).toEqual([1, 2]);
  });
});
